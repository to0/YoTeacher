//
//  EMChatImageBubble.h
//  ChatDemo-UI2.0
//
//  Created by dujiepeng on 14-5-26.
//  Copyright (c) 2014年 dujiepeng. All rights reserved.
//

#import "EMChatCellBubble.h"

@interface EMChatCellImageBubble : EMChatCellBubble

@end
